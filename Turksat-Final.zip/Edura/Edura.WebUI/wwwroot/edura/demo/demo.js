
$(document).ready(function($){
	'use strict';

	$("#demo-lunar").click(function(){
		$("#colorstyle").attr("href", "styles/lunar.css");
	});

	$("#demo-blue").click(function(){
		$("#colorstyle").attr("href", "styles/blue.css");
	});

	$("#demo-green").click(function(){
		$("#colorstyle").attr("href", "styles/green.css");
	});

	$("#demo-red").click(function(){
		$("#colorstyle").attr("href", "styles/red.css");
	});

	$("#demo-orange").click(function(){
		$("#colorstyle").attr("href", "styles/orange.css");
	});


});
